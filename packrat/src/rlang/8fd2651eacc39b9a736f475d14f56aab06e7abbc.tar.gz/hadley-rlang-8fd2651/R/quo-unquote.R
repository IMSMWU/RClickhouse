#' Process unquote operators in a captured expression.
#'
#' While all capturing functions in the tidy evaluation framework
#' perform unquote on capture (most notably [quo()]),
#' `expr_interp()` manually processes unquoting operators in
#' expressions that are already captured. `expr_interp()` should be
#' called in all user-facing functions expecting a formula as argument
#' to provide the same quasiquotation functionality as NSE functions.
#'
#' @param x A function, raw expression, or formula to interpolate.
#' @param env The environment in which unquoted expressions should be
#'   evaluated. By default, the formula or closure environment if a
#'   formula or a function, or the current environment otherwise.
#' @export
#' @examples
#' # All tidy NSE functions like quo() unquote on capture:
#' quo(list(!! 1 + 2))
#'
#' # expr_interp() is meant to provide the same functionality when you
#' # have a formula or expression that might contain unquoting
#' # operators:
#' f <- ~list(!! 1 + 2)
#' expr_interp(f)
#'
#' # Note that only the outer formula is unquoted (which is a reason
#' # to use expr_interp() as early as possible in all user-facing
#' # functions):
#' f <- ~list(~!! 1 + 2, !! 1 + 2)
#' expr_interp(f)
#'
#'
#' # Another purpose for expr_interp() is to interpolate a closure's
#' # body. This is useful to inline a function within another. The
#' # important limitation is that all formal arguments of the inlined
#' # function should be defined in the receiving function:
#' other_fn <- function(x) toupper(x)
#'
#' fn <- expr_interp(function(x) {
#'   x <- paste0(x, "_suffix")
#'   !!! body(other_fn)
#' })
#' fn
#' fn("foo")
expr_interp <- function(x, env = NULL) {
  if (is_formula(x)) {
    expr <- .Call(rlang_interp, f_rhs(x), env %||% f_env(x), TRUE)
    x <- new_quosure(expr, f_env(x))
  } else if (is_closure(x)) {
    body(x) <- .Call(rlang_interp, body(x), env %||% fn_env(x), TRUE)
  } else {
    x <- .Call(rlang_interp, x, env %||% parent.frame(), TRUE)
  }
  x
}

#' Quasiquotation.
#' @name quasiquotation
NULL

#' @export
#' @rdname quosure
UQ <- function(x) {
  x
}
#' @export
#' @rdname quosure
UQE <- function(x) {
  if (is_formula(x)) {
    get_expr(x)
  } else {
    x
  }
}
#' @export
#' @rdname quosure
`!!` <- UQE
#' @export
#' @rdname quosure
UQS <- function(x) {
  if (is_pairlist(x) || is_null(x)) {
    x
  } else if (is_vector(x)) {
    as.pairlist(x)
  } else if (identical(node_car(x), sym_curly)) {
    node_cdr(x)
  } else if (is_expr(x)) {
    pairlist(x)
  } else {
    abort("`x` must be a vector or a language object")
  }
}
#' @export
#' @rdname quosure
#' @usage NULL
`!!!` <- UQS
