## Test environments
* local OS X install, R 3.3.2
* ubuntu 12.04 (on travis-ci), R-release, R-devel
* Rhub

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.

* Possibly mis-spelled words in DESCRIPTION:
    Docstrings (6:89)
This is the proper spelling of the python term.

* Found the following (possibly) invalid URLs:
  URL: https://cran.r-project.org/package=glue
    From: README.md
    Status: 404
    Message: Not Found

This URL will be valid once the glue package is accepted on CRAN.


## Reverse dependencies

This is a new release, so there are no reverse dependencies.
